import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
import numpy as np

FONT = "Arial"
BLUE_FILL = PatternFill("solid", fgColor="DCE6F1")
HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
INPUT_FONT_COLOR = "0000FF"
YELLOW_FILL = PatternFill("solid", fgColor="FFFF00")
THIN = Side(style="thin", color="B7B7B7")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

wb = openpyxl.Workbook()

# ============================================================
# README
# ============================================================
ws = wb.active
ws.title = "README"
ws.sheet_view.showGridLines = False
ws.column_dimensions["A"].width = 105

lines = [
    ("Heat Exchanger DOE Workbook — v2 (Double-Pipe, CHE 330 rig)", 16, True),
    ("", 11, False),
    ("Updated for the real NC State CHE 330 double-pipe rig, per the official lab handout.", 11, False),
    ("Hot stream flows in the inner tube. Cold stream flows in the annulus (outer pipe). Counter-current only.", 11, False),
    ("", 11, False),
    ("Sheets:", 12, True),
    ("  Geometry        -  real rig dimensions (Table 1 of handout) and derived annulus hydraulic diameter.", 11, False),
    ("  Water Properties -  reference density/viscosity/Cp/k vs. temperature (NIST data, do not edit).", 11, False),
    ("  Trial Log        -  4x4 factorial (16 trials), counter-current only. Blue cells = editable.", 11, False),
    ("                      Includes midpoint temperature columns (rig has 6 thermistors: in/mid/out x2).", 11, False),
    ("  Physics Model     -  auto-calculates predicted Q, outlet/midpoint temps, dP, pumping power.", 11, False),
    ("  Wilson Analysis   -  empirical h_i, h_o from YOUR data via Eq. 11-12 (independent of Dittus-Boelter).", 11, False),
    ("  Reference Data    -  prior semester's counter-current 16-run dataset, for baseline comparison.", 11, False),
    ("", 11, False),
    ("Color legend:", 12, True),
    ("  Blue text / light blue fill  =  editable input cell", 11, False),
    ("  Black text                  =  formula, do not overwrite", 11, False),
    ("  Yellow fill                 =  key assumption, verify before trusting results", 11, False),
    ("", 11, False),
    ("Source: M. Cooper, P. Lim, K. Dickey & A. Crothers, CHE 330 Heat Exchanger Experiment Handout, NC State, rev. 1/6/2018.", 10, False),
]
r = 1
for text, size, bold in lines:
    c = ws.cell(row=r, column=1, value=text)
    c.font = Font(name=FONT, size=size, bold=bold, color="1F4E78" if bold else "000000")
    r += 1

# ============================================================
# Geometry — real double-pipe dims
# ============================================================
ws = wb.create_sheet("Geometry")
ws.sheet_view.showGridLines = False
headers = ["Parameter", "Value", "Units", "Notes"]
widths = [38, 14, 10, 55]
for i, (h, w) in enumerate(zip(headers, widths), start=1):
    cell = ws.cell(row=1, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF")
    cell.fill = HEADER_FILL
    ws.column_dimensions[get_column_letter(i)].width = w

geo_rows = [
    ("Inner pipe OD", 0.0127, "m", "Handout Table 1"),
    ("Inner pipe wall thickness", 0.00076, "m", "Handout Table 1"),
    ("Outer pipe OD", 0.0190, "m", "Handout Table 1"),
    ("Outer pipe wall thickness", 0.00124, "m", "Handout Table 1"),
    ("Length (single pass)", 3.048, "m", "Handout Table 1"),
    ("Wall thermal conductivity (Type 314 SS)", 16.3, "W/m-K", "Approximate — handout does not give an exact value; refine if needed"),
    ("A_inner (Ai, hot-side area)", 0.1070, "m2", "Handout Table 1"),
    ("A_outer (Ao, cold-side area)", 0.1216, "m2", "Handout Table 1"),
    ("A_mean (Aw)", 0.1143, "m2", "Handout Table 1, = 0.5*(Ai+Ao)"),
    ("Pump efficiency", 0.6, "fraction", "Not specified in handout — assumed typical value"),
    ("Total minor loss K (both sides combined)", 2.0, "-", "Not specified in handout — assumed; refine if needed"),
]
for i, (name, val, unit, note) in enumerate(geo_rows, start=2):
    ws.cell(row=i, column=1, value=name).font = Font(name=FONT, size=11)
    vcell = ws.cell(row=i, column=2, value=val)
    vcell.font = Font(name=FONT, size=11, color=INPUT_FONT_COLOR, bold=True)
    vcell.fill = BLUE_FILL
    ws.cell(row=i, column=3, value=unit).font = Font(name=FONT, size=11, italic=True)
    note_cell = ws.cell(row=i, column=4, value=note)
    note_cell.font = Font(name=FONT, size=10, italic=True, color="7F7F7F")
    if "Approximate" in note or "assumed" in note.lower():
        vcell.fill = YELLOW_FILL
    for col in range(1, 5):
        ws.cell(row=i, column=col).border = BORDER

n_geo = len(geo_rows) + 1  # last data row

# Derived geometry (formulas, not hardcoded)
derived_start = n_geo + 3
ws.cell(row=derived_start, column=1, value="Derived geometry (calculated)").font = Font(name=FONT, bold=True, color="1F4E78", size=12)
derived_rows = [
    ("Di, inner pipe ID (tube-side flow dia.)", "=B2-2*B3"),
    ("ID of outer pipe", "=B4-2*B5"),
    ("Annulus flow area, Ah (Eq. 8)", "=PI()*((B%d/2)^2-(B2/2)^2)" % (derived_start + 1 - 0)),  # placeholder, fixed below
]
# Build with explicit row refs (cleaner than formula-chaining across placeholder rows)
r = derived_start + 1
ws.cell(row=r, column=1, value="Di, inner pipe ID (tube-side flow dia.)").font = Font(name=FONT, size=11)
ws.cell(row=r, column=2, value="=B2-2*B3").font = Font(name=FONT, size=11)
ws.cell(row=r, column=3, value="m").font = Font(name=FONT, size=11, italic=True)
Di_row = r
r += 1
ws.cell(row=r, column=1, value="ID of outer pipe").font = Font(name=FONT, size=11)
ws.cell(row=r, column=2, value="=B4-2*B5").font = Font(name=FONT, size=11)
ws.cell(row=r, column=3, value="m").font = Font(name=FONT, size=11, italic=True)
IDouter_row = r
r += 1
ws.cell(row=r, column=1, value="Annulus flow area, Ah (Eq. 8)").font = Font(name=FONT, size=11)
ws.cell(row=r, column=2, value=f"=PI()*((B{IDouter_row}/2)^2-(B2/2)^2)").font = Font(name=FONT, size=11)
ws.cell(row=r, column=3, value="m2").font = Font(name=FONT, size=11, italic=True)
Ah_row = r
r += 1
ws.cell(row=r, column=1, value="Annulus equivalent diameter, Dh (Eq. 9)").font = Font(name=FONT, size=11)
ws.cell(row=r, column=2, value=f"=2*SQRT(B{Ah_row}/PI())").font = Font(name=FONT, size=11)
ws.cell(row=r, column=3, value="m").font = Font(name=FONT, size=11, italic=True)
Dh_row = r
r += 1
ws.cell(row=r, column=1, value="Tube-side flow area").font = Font(name=FONT, size=11)
ws.cell(row=r, column=2, value=f"=PI()*(B{Di_row}/2)^2").font = Font(name=FONT, size=11)
ws.cell(row=r, column=3, value="m2").font = Font(name=FONT, size=11, italic=True)
Atube_row = r

for rr in [Di_row, IDouter_row, Ah_row, Dh_row, Atube_row]:
    for col in range(1, 4):
        ws.cell(row=rr, column=col).border = BORDER

GEO_REFS = {
    "OD_inner": "Geometry!$B$2", "tw_inner": "Geometry!$B$3",
    "OD_outer": "Geometry!$B$4", "tw_outer": "Geometry!$B$5",
    "length": "Geometry!$B$6", "kwall": "Geometry!$B$7",
    "Ai": "Geometry!$B$8", "Ao": "Geometry!$B$9", "Aw": "Geometry!$B$10",
    "pump_eff": "Geometry!$B$11", "minorK": "Geometry!$B$12",
    "Di": f"Geometry!$B${Di_row}", "IDouter": f"Geometry!$B${IDouter_row}",
    "Ah": f"Geometry!$B${Ah_row}", "Dh": f"Geometry!$B${Dh_row}",
    "Atube": f"Geometry!$B${Atube_row}",
}

# ============================================================
# Water Properties
# ============================================================
ws = wb.create_sheet("Water Properties")
ws.sheet_view.showGridLines = False
headers = ["T (C)", "rho (kg/m3)", "mu (Pa-s)", "cp (J/kg-K)", "k (W/m-K)"]
for i, h in enumerate(headers, start=1):
    cell = ws.cell(row=1, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF")
    cell.fill = HEADER_FILL
    ws.column_dimensions[get_column_letter(i)].width = 16

water_data = [
    (10, 999.7, 1.307e-3, 4192, 0.580), (20, 998.2, 1.002e-3, 4184, 0.598),
    (30, 995.7, 0.7975e-3, 4180, 0.615), (40, 992.2, 0.6529e-3, 4179, 0.630),
    (50, 988.0, 0.5468e-3, 4181, 0.643), (60, 983.2, 0.4665e-3, 4185, 0.654),
    (70, 977.8, 0.4035e-3, 4190, 0.663), (80, 971.8, 0.3536e-3, 4197, 0.670),
]
for i, row in enumerate(water_data, start=2):
    for j, val in enumerate(row, start=1):
        c = ws.cell(row=i, column=j, value=val)
        c.font = Font(name=FONT, size=11)
        c.border = BORDER
ws.cell(row=11, column=1, value="Source: NIST Webbook reference points, 1 atm. Interpolated linearly in Physics Model sheet.").font = \
    Font(name=FONT, size=10, italic=True, color="7F7F7F")

WP = "'Water Properties'!"

# ============================================================
# Trial Log — 4x4 factorial, counter-current only
# ============================================================
ws = wb.create_sheet("Trial Log")
ws.sheet_view.showGridLines = False
ws.freeze_panes = "A2"
tl_headers = ["Trial", "Hot Flow (L/min)", "Cold Flow (L/min)",
              "Hot In T (C)", "Hot Mid T (C)", "Hot Out T (C)",
              "Cold In T (C)", "Cold Mid T (C)", "Cold Out T (C)",
              "dP Hot (Pa)", "dP Cold (Pa)", "Notes"]
tl_widths = [8, 15, 15, 13, 13, 13, 13, 13, 13, 13, 13, 25]
for i, (h, w) in enumerate(zip(tl_headers, tl_widths), start=1):
    cell = ws.cell(row=1, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.column_dimensions[get_column_letter(i)].width = w

hot_levels = [4, 5, 6, 7]
cold_levels = [4, 5, 6, 7]
doe_combos = [(hf, cf) for hf in hot_levels for cf in cold_levels]
TOTAL_ROWS = len(doe_combos)  # 16

for idx, (hf, cf) in enumerate(doe_combos):
    rr = idx + 2
    ws.cell(row=rr, column=1, value=idx + 1).font = Font(name=FONT, size=11, bold=True)
    ws.cell(row=rr, column=2, value=hf)
    ws.cell(row=rr, column=3, value=cf)
    for col in range(2, 12):
        c = ws.cell(row=rr, column=col)
        c.font = Font(name=FONT, size=11, color=INPUT_FONT_COLOR)
        c.fill = BLUE_FILL
        c.border = BORDER
    ws.cell(row=rr, column=1).border = BORDER
    ws.cell(row=rr, column=12).border = BORDER

ws.cell(row=TOTAL_ROWS + 3, column=1,
        value="4x4 factorial, counter-current only (16 trials), per CHE 330 handout Section 5. "
              "Flow levels 4-7 L/min shown as a starting point; space evenly over the widest range your rig allows.").font = \
    Font(name=FONT, size=10, italic=True, color="7F7F7F")
ws.cell(row=TOTAL_ROWS + 4, column=1,
        value="Vary one parameter at a time; allow 30-60s to steady state after a flow change, ~15 min after switching modes. "
              "Confirm steady state via |Qhot - Qcold| / Qavg <= 0.15 (handout Eq. 15).").font = \
    Font(name=FONT, size=10, italic=True, color="7F7F7F")

TL = "'Trial Log'!"

# ============================================================
# Physics Model
# ============================================================
ws = wb.create_sheet("Physics Model")
ws.sheet_view.showGridLines = False
ws.freeze_panes = "B2"

pm_headers = [
    "Trial", "Hot Flow (L/min)", "Cold Flow (L/min)",
    "Hot In T meas (C)", "Cold In T meas (C)",
    "Hot T clamped", "Cold T clamped", "Hot idx", "Cold idx",
    "rho_hot", "mu_hot", "cp_hot", "k_hot",
    "rho_cold", "mu_cold", "cp_cold", "k_cold",
    "mdot_hot (kg/s)", "mdot_cold (kg/s)",
    "Re_tube", "Pr_tube", "Nu_tube", "h_i (W/m2K)",
    "Re_annulus", "Pr_annulus", "Nu_annulus", "h_o (W/m2K)",
    "UA (W/K)", "C_hot (W/K)", "C_cold (W/K)", "C_min", "C_max", "Cr",
    "NTU_full", "Eff_full", "Q_max (W)", "Q_pred (W)",
    "NTU_mid", "Eff_mid", "Q_mid_pred (W)",
    "Hot Out T pred (C)", "Cold Out T pred (C)",
    "Hot Mid T pred (C)", "Cold Mid T pred (C)",
    "v_hot (m/s)", "f_hot", "dP_hot pred (Pa)",
    "v_cold (m/s)", "f_cold", "dP_cold pred (Pa)",
    "Pump power hot (W)", "Pump power cold (W)", "Pump power total (W)",
    "Hot Mid T meas", "Hot Out T meas", "Cold Mid T meas", "Cold Out T meas",
    "dP Hot meas", "dP Cold meas",
    "Hot Out T error %", "Cold Out T error %",
    "Hot Mid T error %", "Cold Mid T error %",
    "Q_actual_hot (W)", "Q_actual_cold (W)", "Energy balance closure %",
]
for i, h in enumerate(pm_headers, start=1):
    cell = ws.cell(row=1, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=9)
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.column_dimensions[get_column_letter(i)].width = 12

col_of = {h: get_column_letter(i + 1) for i, h in enumerate(pm_headers)}

for idx in range(TOTAL_ROWS):
    rr = idx + 2
    trial_r = rr

    def C(h):
        return f"{col_of[h]}{rr}"

    ws[f"{col_of['Trial']}{rr}"] = f"={TL}A{trial_r}"
    ws[f"{col_of['Hot Flow (L/min)']}{rr}"] = f"={TL}B{trial_r}"
    ws[f"{col_of['Cold Flow (L/min)']}{rr}"] = f"={TL}C{trial_r}"
    ws[f"{col_of['Hot In T meas (C)']}{rr}"] = f"={TL}D{trial_r}"
    ws[f"{col_of['Cold In T meas (C)']}{rr}"] = f"={TL}G{trial_r}"

    ws[f"{col_of['Hot T clamped']}{rr}"] = f"=IFERROR(MAX(10,MIN(80,{C('Hot In T meas (C)')})),\"\")"
    ws[f"{col_of['Cold T clamped']}{rr}"] = f"=IFERROR(MAX(10,MIN(80,{C('Cold In T meas (C)')})),\"\")"
    ws[f"{col_of['Hot idx']}{rr}"] = f"=IFERROR(MATCH({C('Hot T clamped')},{WP}$A$2:$A$9,1),\"\")"
    ws[f"{col_of['Cold idx']}{rr}"] = f"=IFERROR(MATCH({C('Cold T clamped')},{WP}$A$2:$A$9,1),\"\")"

    def interp(idx_cell, t_cell, prop_col):
        return (f"IFERROR(INDEX({WP}${prop_col}$2:${prop_col}$9,{idx_cell})+"
                f"({t_cell}-INDEX({WP}$A$2:$A$9,{idx_cell}))/"
                f"(INDEX({WP}$A$2:$A$9,{idx_cell}+1)-INDEX({WP}$A$2:$A$9,{idx_cell}))*"
                f"(INDEX({WP}${prop_col}$2:${prop_col}$9,{idx_cell}+1)-INDEX({WP}${prop_col}$2:${prop_col}$9,{idx_cell})),\"\")")

    hidx, hT = C('Hot idx'), C('Hot T clamped')
    cidx, cT = C('Cold idx'), C('Cold T clamped')
    ws[f"{col_of['rho_hot']}{rr}"] = f"={interp(hidx, hT, 'B')}"
    ws[f"{col_of['mu_hot']}{rr}"] = f"={interp(hidx, hT, 'C')}"
    ws[f"{col_of['cp_hot']}{rr}"] = f"={interp(hidx, hT, 'D')}"
    ws[f"{col_of['k_hot']}{rr}"] = f"={interp(hidx, hT, 'E')}"
    ws[f"{col_of['rho_cold']}{rr}"] = f"={interp(cidx, cT, 'B')}"
    ws[f"{col_of['mu_cold']}{rr}"] = f"={interp(cidx, cT, 'C')}"
    ws[f"{col_of['cp_cold']}{rr}"] = f"={interp(cidx, cT, 'D')}"
    ws[f"{col_of['k_cold']}{rr}"] = f"={interp(cidx, cT, 'E')}"

    hflow, cflow = C('Hot Flow (L/min)'), C('Cold Flow (L/min)')
    rhoh, rhoc = C('rho_hot'), C('rho_cold')
    ws[f"{col_of['mdot_hot (kg/s)']}{rr}"] = f"=IFERROR({hflow}/60000*{rhoh},\"\")"
    ws[f"{col_of['mdot_cold (kg/s)']}{rr}"] = f"=IFERROR({cflow}/60000*{rhoc},\"\")"
    mdh, mdc = C('mdot_hot (kg/s)'), C('mdot_cold (kg/s)')
    muh, muc = C('mu_hot'), C('mu_cold')
    cph, cpc = C('cp_hot'), C('cp_cold')
    kh, kc = C('k_hot'), C('k_cold')

    # Tube side (hot)
    ws[f"{col_of['Re_tube']}{rr}"] = f"=IFERROR(4*{mdh}/(PI()*{GEO_REFS['Di']}*{muh}),\"\")"
    ws[f"{col_of['Pr_tube']}{rr}"] = f"=IFERROR({muh}*{cph}/{kh},\"\")"
    ret, prt = C('Re_tube'), C('Pr_tube')
    ws[f"{col_of['Nu_tube']}{rr}"] = f"=IFERROR(IF({ret}<2300,3.66,0.023*{ret}^0.8*{prt}^0.3),\"\")"
    nut = C('Nu_tube')
    ws[f"{col_of['h_i (W/m2K)']}{rr}"] = f"=IFERROR({nut}*{kh}/{GEO_REFS['Di']},\"\")"
    hi = C('h_i (W/m2K)')

    # Annulus side (cold)
    ws[f"{col_of['Re_annulus']}{rr}"] = f"=IFERROR(4*{mdc}/(PI()*{GEO_REFS['Dh']}*{muc}),\"\")"
    ws[f"{col_of['Pr_annulus']}{rr}"] = f"=IFERROR({muc}*{cpc}/{kc},\"\")"
    rea, pra = C('Re_annulus'), C('Pr_annulus')
    ws[f"{col_of['Nu_annulus']}{rr}"] = f"=IFERROR(IF({rea}<2300,3.66,0.023*{rea}^0.8*{pra}^0.3),\"\")"
    nua = C('Nu_annulus')
    ws[f"{col_of['h_o (W/m2K)']}{rr}"] = f"=IFERROR({nua}*{kc}/{GEO_REFS['Dh']},\"\")"
    ho = C('h_o (W/m2K)')

    # UA (Eq. 5, no fouling term)
    ws[f"{col_of['UA (W/K)']}{rr}"] = (
        f"=IFERROR(1/(1/({hi}*{GEO_REFS['Ai']})+{GEO_REFS['tw_inner']}/({GEO_REFS['kwall']}*{GEO_REFS['Aw']})"
        f"+1/({ho}*{GEO_REFS['Ao']})),\"\")")
    ua = C('UA (W/K)')

    ws[f"{col_of['C_hot (W/K)']}{rr}"] = f"=IFERROR({mdh}*{cph},\"\")"
    ws[f"{col_of['C_cold (W/K)']}{rr}"] = f"=IFERROR({mdc}*{cpc},\"\")"
    chot, ccold = C('C_hot (W/K)'), C('C_cold (W/K)')
    ws[f"{col_of['C_min']}{rr}"] = f"=IFERROR(MIN({chot},{ccold}),\"\")"
    ws[f"{col_of['C_max']}{rr}"] = f"=IFERROR(MAX({chot},{ccold}),\"\")"
    cmin, cmax = C('C_min'), C('C_max')
    ws[f"{col_of['Cr']}{rr}"] = f"=IFERROR({cmin}/{cmax},\"\")"
    cr = C('Cr')

    hin, cin = C('Hot In T meas (C)'), C('Cold In T meas (C)')
    ws[f"{col_of['Q_max (W)']}{rr}"] = f"=IFERROR({cmin}*({hin}-{cin}),\"\")"
    qmax = C('Q_max (W)')

    # Full-length (outlet) effectiveness-NTU, counter-current only
    ws[f"{col_of['NTU_full']}{rr}"] = f"=IFERROR({ua}/{cmin},\"\")"
    ntuf = C('NTU_full')
    ws[f"{col_of['Eff_full']}{rr}"] = (
        f"=IFERROR(IF({cr}<1,(1-EXP(-{ntuf}*(1-{cr})))/(1-{cr}*EXP(-{ntuf}*(1-{cr}))),{ntuf}/(1+{ntuf})),\"\")")
    epsf = C('Eff_full')
    ws[f"{col_of['Q_pred (W)']}{rr}"] = f"=IFERROR({epsf}*{qmax},\"\")"
    qpred = C('Q_pred (W)')

    # Midpoint (half-length) effectiveness-NTU
    ws[f"{col_of['NTU_mid']}{rr}"] = f"=IFERROR(0.5*{ua}/{cmin},\"\")"
    ntum = C('NTU_mid')
    ws[f"{col_of['Eff_mid']}{rr}"] = (
        f"=IFERROR(IF({cr}<1,(1-EXP(-{ntum}*(1-{cr})))/(1-{cr}*EXP(-{ntum}*(1-{cr}))),{ntum}/(1+{ntum})),\"\")")
    epsm = C('Eff_mid')
    ws[f"{col_of['Q_mid_pred (W)']}{rr}"] = f"=IFERROR({epsm}*{qmax},\"\")"
    qmidpred = C('Q_mid_pred (W)')

    ws[f"{col_of['Hot Out T pred (C)']}{rr}"] = f"=IFERROR({hin}-{qpred}/{chot},\"\")"
    ws[f"{col_of['Cold Out T pred (C)']}{rr}"] = f"=IFERROR({cin}+{qpred}/{ccold},\"\")"
    ws[f"{col_of['Hot Mid T pred (C)']}{rr}"] = f"=IFERROR({hin}-{qmidpred}/{chot},\"\")"
    ws[f"{col_of['Cold Mid T pred (C)']}{rr}"] = f"=IFERROR({cin}+{qmidpred}/{ccold},\"\")"

    # Pressure drop
    ws[f"{col_of['v_hot (m/s)']}{rr}"] = f"=IFERROR({mdh}/({rhoh}*{GEO_REFS['Atube']}),\"\")"
    vhot = C('v_hot (m/s)')
    ws[f"{col_of['f_hot']}{rr}"] = f"=IFERROR(IF({ret}<2300,64/{ret},(-1.8*LOG10((0.00001/3.7)^1.11+6.9/{ret}))^-2),\"\")"
    fhot = C('f_hot')
    ws[f"{col_of['dP_hot pred (Pa)']}{rr}"] = (
        f"=IFERROR({fhot}*({GEO_REFS['length']}/{GEO_REFS['Di']})*({rhoh}*{vhot}^2/2)"
        f"+({GEO_REFS['minorK']}/2)*({rhoh}*{vhot}^2/2),\"\")")

    ws[f"{col_of['v_cold (m/s)']}{rr}"] = f"=IFERROR({mdc}/({rhoc}*{GEO_REFS['Ah']}),\"\")"
    vcold = C('v_cold (m/s)')
    ws[f"{col_of['f_cold']}{rr}"] = f"=IFERROR(IF({rea}<2300,64/{rea},(-1.8*LOG10((0.00001/3.7)^1.11+6.9/{rea}))^-2),\"\")"
    fcold = C('f_cold')
    ws[f"{col_of['dP_cold pred (Pa)']}{rr}"] = (
        f"=IFERROR({fcold}*({GEO_REFS['length']}/{GEO_REFS['Dh']})*({rhoc}*{vcold}^2/2)"
        f"+({GEO_REFS['minorK']}/2)*({rhoc}*{vcold}^2/2),\"\")")

    dph, dpc = C('dP_hot pred (Pa)'), C('dP_cold pred (Pa)')
    ws[f"{col_of['Pump power hot (W)']}{rr}"] = f"=IFERROR({dph}*({hflow}/60000)/{GEO_REFS['pump_eff']},\"\")"
    ws[f"{col_of['Pump power cold (W)']}{rr}"] = f"=IFERROR({dpc}*({cflow}/60000)/{GEO_REFS['pump_eff']},\"\")"
    pph, ppc = C('Pump power hot (W)'), C('Pump power cold (W)')
    ws[f"{col_of['Pump power total (W)']}{rr}"] = f"=IFERROR({pph}+{ppc},\"\")"

    # Measured values (from Trial Log)
    ws[f"{col_of['Hot Mid T meas']}{rr}"] = f"={TL}E{trial_r}"
    ws[f"{col_of['Hot Out T meas']}{rr}"] = f"={TL}F{trial_r}"
    ws[f"{col_of['Cold Mid T meas']}{rr}"] = f"={TL}H{trial_r}"
    ws[f"{col_of['Cold Out T meas']}{rr}"] = f"={TL}I{trial_r}"
    ws[f"{col_of['dP Hot meas']}{rr}"] = f"={TL}J{trial_r}"
    ws[f"{col_of['dP Cold meas']}{rr}"] = f"={TL}K{trial_r}"

    houtp, coutp = C('Hot Out T pred (C)'), C('Cold Out T pred (C)')
    houtm, coutm = C('Hot Out T meas'), C('Cold Out T meas')
    hmidp, cmidp = C('Hot Mid T pred (C)'), C('Cold Mid T pred (C)')
    hmidm, cmidm = C('Hot Mid T meas'), C('Cold Mid T meas')
    ws[f"{col_of['Hot Out T error %']}{rr}"] = f"=IFERROR(ABS({houtp}-{houtm})/{houtm},\"\")"
    ws[f"{col_of['Cold Out T error %']}{rr}"] = f"=IFERROR(ABS({coutp}-{coutm})/{coutm},\"\")"
    ws[f"{col_of['Hot Mid T error %']}{rr}"] = f"=IFERROR(ABS({hmidp}-{hmidm})/{hmidm},\"\")"
    ws[f"{col_of['Cold Mid T error %']}{rr}"] = f"=IFERROR(ABS({cmidp}-{cmidm})/{cmidm},\"\")"

    ws[f"{col_of['Q_actual_hot (W)']}{rr}"] = f"=IFERROR({cph}*{mdh}*({hin}-{houtm}),\"\")"
    ws[f"{col_of['Q_actual_cold (W)']}{rr}"] = f"=IFERROR({cpc}*{mdc}*({coutm}-{cin}),\"\")"
    qah, qac = C('Q_actual_hot (W)'), C('Q_actual_cold (W)')
    ws[f"{col_of['Energy balance closure %']}{rr}"] = f"=IFERROR(ABS({qah}-{qac})/(({qah}+{qac})/2),\"\")"

    for col in range(1, len(pm_headers) + 1):
        ws.cell(row=rr, column=col).font = Font(name=FONT, size=10)
        ws.cell(row=rr, column=col).border = BORDER

pct_cols = ["Eff_full", "Eff_mid", "Cr", "Hot Out T error %", "Cold Out T error %",
            "Hot Mid T error %", "Cold Mid T error %", "Energy balance closure %"]
for h in pct_cols:
    col_letter = col_of[h]
    for rr in range(2, TOTAL_ROWS + 2):
        ws[f"{col_letter}{rr}"].number_format = "0.0%"

# ============================================================
# Reference Data — prior semester counter-current dataset
# ============================================================
ws = wb.create_sheet("Reference Data")
ws.sheet_view.showGridLines = False
ref_headers = ["Run", "Hot Flow (L/min)", "Cold Flow (L/min)",
               "Hot In T (C)", "Hot Mid T (C)", "Hot Out T (C)",
               "Cold In T (C)", "Cold Mid T (C)", "Cold Out T (C)"]
for i, h in enumerate(ref_headers, start=1):
    cell = ws.cell(row=1, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
    cell.fill = HEADER_FILL
    ws.column_dimensions[get_column_letter(i)].width = 14

reference_data = [
    (1, 4, 4, 58.3, 48.6, 39.2, 11.0, 16.0, 25.7),
    (2, 4, 5, 58.9, 47.7, 38.5, 11.3, 16.4, 24.8),
    (3, 4, 6, 58.2, 46.6, 37.0, 11.2, 15.6, 23.4),
    (4, 4, 7, 57.4, 45.1, 35.5, 11.1, 14.9, 22.0),
    (5, 5, 4, 50.2, 43.8, 37.3, 11.3, 17.2, 24.7),
    (6, 5, 5, 50.3, 42.9, 36.0, 11.2, 16.2, 23.3),
    (7, 5, 6, 50.5, 42.8, 35.7, 11.1, 15.8, 22.7),
    (8, 5, 7, 52.1, 42.9, 35.4, 11.1, 15.2, 22.1),
    (9, 6, 4, 50.1, 44.8, 39.1, 11.4, 18.0, 26.0),
    (10, 6, 5, 50.1, 44.0, 37.9, 11.3, 17.0, 24.7),
    (11, 6, 6, 50.1, 43.4, 36.9, 11.2, 16.3, 23.6),
    (12, 6, 7, 50.1, 42.8, 36.0, 11.2, 15.6, 22.5),
    (13, 7, 4, 44.9, 40.9, 36.6, 11.2, 17.4, 24.5),
    (14, 7, 5, 45.5, 40.8, 36.1, 11.2, 16.7, 23.7),
    (15, 7, 6, 48.0, 42.1, 36.9, 11.2, 16.5, 23.8),
    (16, 7, 7, 50.0, 43.6, 37.4, 11.1, 16.3, 23.3),
]
for i, row in enumerate(reference_data, start=2):
    for j, val in enumerate(row, start=1):
        c = ws.cell(row=i, column=j, value=val)
        c.font = Font(name=FONT, size=10)
        c.border = BORDER
ws.cell(row=19, column=1,
        value="Source: prior semester's counter-current trials (Heat_Exchanger_raw_data.xlsx). "
              "Flow uncertainty +/-0.25 L/min (hot), +/-0.5 L/min (cold); temperature uncertainty +/-0.005 C.").font = \
    Font(name=FONT, size=10, italic=True, color="7F7F7F")

RD = "'Reference Data'!"

# ============================================================
# Wilson Analysis
# ============================================================
ws = wb.create_sheet("Wilson Analysis")
ws.sheet_view.showGridLines = False
ws.column_dimensions["A"].width = 42
for col in "BCDEFGHIJ":
    ws.column_dimensions[col].width = 14

ws["A1"] = "Wilson's Method of Analysis (Eq. 11-12) — applied to Reference Data"
ws["A1"].font = Font(name=FONT, size=13, bold=True, color="1F4E78")
ws["A2"] = "Computes UA from measured data (energy balance + counter-current LMTD), then regresses 1/UA vs 1/v^0.8."
ws["A2"].font = Font(name=FONT, size=10, italic=True, color="7F7F7F")

calc_headers = ["Run", "Hot Flow", "Cold Flow", "mdot_hot", "mdot_cold",
                "Q_hot (W)", "Q_cold (W)", "Q_avg (W)", "Energy bal. %",
                "LMTD (C)", "UA (W/K)", "v_hot (m/s)", "v_cold (m/s)",
                "1/UA", "1/v_hot^0.8", "1/v_cold^0.8"]
hdr_row = 4
for i, h in enumerate(calc_headers, start=1):
    cell = ws.cell(row=hdr_row, column=i, value=h)
    cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=9)
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.column_dimensions[get_column_letter(i)].width = 11

wcol = {h: get_column_letter(i + 1) for i, h in enumerate(calc_headers)}

for idx in range(16):
    rr = hdr_row + 1 + idx
    src_r = idx + 2  # Reference Data row

    def W(h):
        return f"{wcol[h]}{rr}"

    ws[f"{wcol['Run']}{rr}"] = f"={RD}A{src_r}"
    ws[f"{wcol['Hot Flow']}{rr}"] = f"={RD}B{src_r}"
    ws[f"{wcol['Cold Flow']}{rr}"] = f"={RD}C{src_r}"

    hin = f"{RD}D{src_r}"
    hout = f"{RD}F{src_r}"
    cin = f"{RD}G{src_r}"
    cout = f"{RD}I{src_r}"

    # property lookups at inlet T (clamped)
    hT_clamp = f"MAX(10,MIN(80,{hin}))"
    cT_clamp = f"MAX(10,MIN(80,{cin}))"
    hidx = f"MATCH({hT_clamp},{WP}$A$2:$A$9,1)"
    cidx = f"MATCH({cT_clamp},{WP}$A$2:$A$9,1)"

    def interp2(idxf, tf, prop_col):
        return (f"(INDEX({WP}${prop_col}$2:${prop_col}$9,{idxf})+"
                f"({tf}-INDEX({WP}$A$2:$A$9,{idxf}))/"
                f"(INDEX({WP}$A$2:$A$9,{idxf}+1)-INDEX({WP}$A$2:$A$9,{idxf}))*"
                f"(INDEX({WP}${prop_col}$2:${prop_col}$9,{idxf}+1)-INDEX({WP}${prop_col}$2:${prop_col}$9,{idxf})))")

    rho_h_f = interp2(hidx, hT_clamp, 'B')
    cp_h_f = interp2(hidx, hT_clamp, 'D')
    rho_c_f = interp2(cidx, cT_clamp, 'B')
    cp_c_f = interp2(cidx, cT_clamp, 'D')

    hflow_c = W('Hot Flow')
    cflow_c = W('Cold Flow')
    ws[f"{wcol['mdot_hot']}{rr}"] = f"=IFERROR({hflow_c}/60000*{rho_h_f},\"\")"
    ws[f"{wcol['mdot_cold']}{rr}"] = f"=IFERROR({cflow_c}/60000*{rho_c_f},\"\")"
    mdh, mdc = W('mdot_hot'), W('mdot_cold')

    ws[f"{wcol['Q_hot (W)']}{rr}"] = f"=IFERROR({mdh}*{cp_h_f}*({hin}-{hout}),\"\")"
    ws[f"{wcol['Q_cold (W)']}{rr}"] = f"=IFERROR({mdc}*{cp_c_f}*({cout}-{cin}),\"\")"
    qh, qc = W('Q_hot (W)'), W('Q_cold (W)')
    ws[f"{wcol['Q_avg (W)']}{rr}"] = f"=IFERROR(({qh}+{qc})/2,\"\")"
    qavg = W('Q_avg (W)')
    ws[f"{wcol['Energy bal. %']}{rr}"] = f"=IFERROR(ABS({qh}-{qc})/{qavg},\"\")"
    ws[f"{wcol['Energy bal. %']}{rr}"].number_format = "0.0%"

    # Counter-current LMTD: ends are (hot_in - cold_out) and (hot_out - cold_in)
    dT1 = f"({hin}-{cout})"
    dT2 = f"({hout}-{cin})"
    ws[f"{wcol['LMTD (C)']}{rr}"] = f"=IFERROR(({dT1}-{dT2})/LN({dT1}/{dT2}),\"\")"
    lmtd = W('LMTD (C)')
    ws[f"{wcol['UA (W/K)']}{rr}"] = f"=IFERROR({qavg}/{lmtd},\"\")"
    ua = W('UA (W/K)')

    ws[f"{wcol['v_hot (m/s)']}{rr}"] = f"=IFERROR({mdh}/({rho_h_f}*{GEO_REFS['Atube']}),\"\")"
    ws[f"{wcol['v_cold (m/s)']}{rr}"] = f"=IFERROR({mdc}/({rho_c_f}*{GEO_REFS['Ah']}),\"\")"
    vh, vc = W('v_hot (m/s)'), W('v_cold (m/s)')

    ws[f"{wcol['1/UA']}{rr}"] = f"=IFERROR(1/{ua},\"\")"
    ws[f"{wcol['1/v_hot^0.8']}{rr}"] = f"=IFERROR(1/{vh}^0.8,\"\")"
    ws[f"{wcol['1/v_cold^0.8']}{rr}"] = f"=IFERROR(1/{vc}^0.8,\"\")"

    for col in range(1, len(calc_headers) + 1):
        ws.cell(row=rr, column=col).font = Font(name=FONT, size=9)
        ws.cell(row=rr, column=col).border = BORDER

last_data_row = hdr_row + 16
inv_UA_range = f"${wcol['1/UA']}${hdr_row+1}:${wcol['1/UA']}${last_data_row}"
inv_vhot_range = f"${wcol['1/v_hot^0.8']}${hdr_row+1}:${wcol['1/v_hot^0.8']}${last_data_row}"
inv_vcold_range = f"${wcol['1/v_cold^0.8']}${hdr_row+1}:${wcol['1/v_cold^0.8']}${last_data_row}"

# Wilson regression results
res_row = last_data_row + 3
ws.cell(row=res_row, column=1, value="Wilson plot regression results (full 16-point dataset, both factors mixed)").font = \
    Font(name=FONT, bold=True, color="1F4E78", size=12)
ws.cell(row=res_row+1, column=1, value="Note: handout recommends isolating one stream at a time (hold the other's flow constant) "
                                        "for a cleaner fit. This full-dataset regression is a quick overall check; "
                                        "filter to a fixed cold (or hot) flow subset for the rigorous version.").font = \
    Font(name=FONT, size=9, italic=True, color="7F7F7F")

labels = [
    ("Hot-side slope (1/(alpha_i*Ai))", f"=SLOPE({inv_UA_range},{inv_vhot_range})"),
    ("Hot-side intercept (Ci)", f"=INTERCEPT({inv_UA_range},{inv_vhot_range})"),
    ("Hot-side R-squared", f"=RSQ({inv_UA_range},{inv_vhot_range})"),
    ("alpha_i * Ai (= 1/slope)", None),  # filled below referencing slope cell
    ("Cold-side slope (1/(alpha_o*Ao))", f"=SLOPE({inv_UA_range},{inv_vcold_range})"),
    ("Cold-side intercept (Co)", f"=INTERCEPT({inv_UA_range},{inv_vcold_range})"),
    ("Cold-side R-squared", f"=RSQ({inv_UA_range},{inv_vcold_range})"),
    ("alpha_o * Ao (= 1/slope)", None),
]
rr = res_row + 3
cell_refs = {}
for label, formula in labels:
    ws.cell(row=rr, column=1, value=label).font = Font(name=FONT, size=11)
    if formula is not None:
        fcell = ws.cell(row=rr, column=2, value=formula)
        fcell.font = Font(name=FONT, size=11, bold=True)
        cell_refs[label] = f"B{rr}"
    else:
        # alpha*A = 1/slope — reference the slope cell two rows above(ish); fill after loop
        pass
    for col in [1, 2]:
        ws.cell(row=rr, column=col).border = BORDER
    rr += 1

# Now fill the two alpha*A rows referencing their slope cells
hot_slope_ref = cell_refs["Hot-side slope (1/(alpha_i*Ai))"]
cold_slope_ref = cell_refs["Cold-side slope (1/(alpha_o*Ao))"]
alphaAi_row = res_row + 3 + 3  # 0-indexed position of "alpha_i * Ai" label
alphaAo_row = res_row + 3 + 7
ws.cell(row=alphaAi_row, column=2, value=f"=1/{hot_slope_ref}").font = Font(name=FONT, size=11, bold=True)
ws.cell(row=alphaAo_row, column=2, value=f"=1/{cold_slope_ref}").font = Font(name=FONT, size=11, bold=True)

# ============================================================
# DOE Analysis
# ============================================================
ws = wb.create_sheet("DOE Analysis")
ws.sheet_view.showGridLines = False
ws.column_dimensions["A"].width = 30
ws.column_dimensions["B"].width = 18
ws.column_dimensions["C"].width = 50

ws["A1"] = "Main Effects on Predicted Heat Duty (4x4 factorial, your own Trial Log data)"
ws["A1"].font = Font(name=FONT, size=13, bold=True, color="1F4E78")

ws["A3"] = "Factor"
ws["B3"] = "Effect on Q (W)"
ws["C3"] = "Interpretation"
for col in ["A3", "B3", "C3"]:
    ws[col].font = Font(name=FONT, bold=True, color="FFFFFF")
    ws[col].fill = HEADER_FILL

PM = "'Physics Model'!"
hf_col = col_of['Hot Flow (L/min)']
cf_col = col_of['Cold Flow (L/min)']
q_col = col_of['Q_pred (W)']
rng_hf = f"{PM}${hf_col}$2:${hf_col}${TOTAL_ROWS+1}"
rng_cf = f"{PM}${cf_col}$2:${cf_col}${TOTAL_ROWS+1}"
rng_q = f"{PM}${q_col}$2:${q_col}${TOTAL_ROWS+1}"

ws["A4"] = "Hot Flow (4 -> 7 L/min)"
ws["B4"] = f"=IFERROR(AVERAGEIF({rng_hf},7,{rng_q})-AVERAGEIF({rng_hf},4,{rng_q}),\"\")"
ws["C4"] = "Average change in predicted Q when hot flow goes from low to high level"

ws["A5"] = "Cold Flow (4 -> 7 L/min)"
ws["B5"] = f"=IFERROR(AVERAGEIF({rng_cf},7,{rng_q})-AVERAGEIF({rng_cf},4,{rng_q}),\"\")"
ws["C5"] = "Average change in predicted Q when cold flow goes from low to high level"

for rr in [4, 5]:
    for col in [1, 2, 3]:
        ws.cell(row=rr, column=col).font = Font(name=FONT, size=11)
        ws.cell(row=rr, column=col).border = BORDER
ws["B4"].number_format = "0.0"
ws["B5"].number_format = "0.0"

ws["A7"] = "Based on your own 16-trial Trial Log (Physics Model sheet), not the Reference Data."
ws["A7"].font = Font(name=FONT, size=10, italic=True, color="7F7F7F")

wb.save("heat_exchanger_doe_workbook.xlsx")
print("saved")

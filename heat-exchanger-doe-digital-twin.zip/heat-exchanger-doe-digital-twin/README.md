# Double-Pipe Heat Exchanger: DOE, Digital Twin and Transient Model

NC State CHE 330, Fall 2026. Team project: a designed experiment on a bench-scale counter-current double-pipe heat exchanger, a first-principles digital twin, statistical analysis in JMP, and a MATLAB transient model of the hot reservoir.

## What was done

1. **DOE.** 4×4 full factorial: hot flow 2/3/4/5 L/min × cold flow 4/5/6/7 L/min, 16 trials in one session (hot inlet about 55 °C, cold inlet about 10 °C). Each trial is screened with an energy-balance check, |Q_hot − Q_cold| / Q_avg ≤ 15%.
2. **Digital twin (Python).** e-NTU model with Dittus-Boelter film coefficients, Darcy-Weisbach pressure drop, and an exact counter-current midpoint temperature profile. Predicts outlet and midpoint temperatures from flows and inlet temperatures.
3. **Wilson analysis (JMP).** Regression of 1/UA on the hot-side and cold-side velocity terms (v^-0.8) to separate tube-side and annulus-side resistance.
4. **Validation (JMP).** Predicted vs measured for hot/cold outlet and midpoint temperatures, error by trial, and control charts (I-MR) with baseline limits from the valid trials.
5. **Transient model (MATLAB).** Lumped hot-reservoir energy balance (heater with thermostat minus heat removed by the exchanger), solved with `ode45`, with reservoir mass and heater power fitted to the measured hot-inlet temperature.

## Key results

| Item | Result |
|---|---|
| Valid trials | 12 of 16 (trials 5–16). Trials 1–4 (hot flow 2 L/min) failed the energy balance, with closure 110–120%, and could not be repeated. Trial 9 is borderline at 15.6%. |
| Wilson fit, 1/UA (12 trials) | R² = 0.946 (adj. 0.934), both terms p < 0.0001. Hot-side term is the stronger driver (logworth 5.5 vs 4.4). |
| Wilson coefficients | intercept 0.0003885 (not significant, p = 0.40), hot 0.0022158, cold 0.0022736 |
| Single-flow sweeps | Individual sweep fits reached R² = 0.975–0.999, but each uses only four points. |
| First-principles twin vs measured (12 valid trials) | Mean absolute error: hot outlet 1.1 °C, cold outlet 1.2 °C, hot midpoint 0.4 °C, cold midpoint 1.4 °C. This is the uncalibrated physics model. |
| Wilson-calibrated e-NTU (MATLAB `hx_model.m`) | Spot checks on trials 10, 6 and 16 gave hot-outlet predictions within 0.2 °C of measured. Not computed across all trials. |
| Transient model | Fitted reservoir mass about 28–30 kg. RMSE 0.35 °C on trials 1–15. |

## Data-quality notes

- **Trials 1–4** fail the energy balance. The hot rotameter is suspected at its low end. They are kept in the all-16 analyses but flagged, and headline numbers use the 12 valid trials.
- **Trial 16** shows the hot inlet dropping to 49 °C. The transient model cannot reproduce this without the heater switching off, and nothing in the data shows that happened, so it is excluded from the transient fit.
- **Heater power is not identified.** The fit gives 4.9 kW (all 16 points) or 6.8 kW (trials 1–15), because the heater is never the limiting factor in the fitted range. Treat the fitted mass as the robust value, and the heater power as only a lower bound.
- **Pressure drop** is model-only. The rig has no pressure gauges, so there is no measured dP to validate against.
- Some inputs are assumptions: wall conductivity 16.3 W/m·K, minor-loss K = 2.0, pump efficiency 0.6.
- Trial 13 hot midpoint was corrected to 47.2 °C (a transcription error in the first entry).

## Repository layout

```
data/
  raw_measurements.csv          16 trials as recorded
  results_for_jmp.csv           Q, energy-balance closure, LMTD, UA, velocities, pass/fail
twin/
  heat_exchanger_digital_twin.py   physics model + helpers
  predicted_vs_measured.csv        twin predictions vs measurements, with valid/excluded flag
doe/
  doe_workbook_with_data.xlsx   trial log, closure check, physics model, Wilson/DOE sheets
  doe_workbook_template.xlsx    empty version of the workbook
  build_workbook.py             script that generates the workbook
jmp/
  Heat_exchanger_Doe.jmp                      DOE analysis (Fit Model on UA and Q)
  p5_heat_exchanger_predicted_vs_measured.jmp validation table
matlab/
  hx_model.m                    exchanger model (Wilson UA + e-NTU)
  transient_model.m             reservoir ODE and parameter fit
  transient_fit.png             model vs measured hot-inlet temperature
```

## Running it

**Python** (numpy, pandas, scipy, openpyxl):

```bash
pip install numpy pandas scipy openpyxl
python twin/heat_exchanger_digital_twin.py     # prints the DOE trial table
python doe/build_workbook.py                   # regenerates the Excel workbook
```

In code, `predict_heat_exchanger(hot_flow_Lmin, cold_flow_Lmin, hot_in_C, cold_in_C)` returns outlet and midpoint temperatures, Q, UA, effectiveness, NTU, pressure drop and pumping power, and `compute_UA_from_measurements(df)` computes Q, closure, LMTD and UA from a measurement table.

**MATLAB** (R2026b, base toolboxes): open the `matlab/` folder and run `transient_model`. It reads `../data/raw_measurements.csv` and prints the fitted mass, heater power and RMSE.

**JMP** (Student Edition): open the `.jmp` files. Saved scripts reproduce the model fits.

## Tools

Python, JMP, MATLAB, Excel.
